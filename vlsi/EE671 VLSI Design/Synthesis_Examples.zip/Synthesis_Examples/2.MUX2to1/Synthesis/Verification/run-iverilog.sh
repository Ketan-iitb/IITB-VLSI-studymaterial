#!/bin/sh

design="mux2to1"
rm -rf ${design}_TB
echo "Testing:" ${design}
iverilog -DFUNCTIONAL -DUNIT_DELAY=#1 -o ${design}_TB ../${design}_map.v ${design}_TB.v  /home/laxmeesha/EE671/sky130_fd_sc_hd/verilog/primitives.v /home/laxmeesha/EE671/sky130_fd_sc_hd/verilog/sky130_fd_sc_hd.v
vvp ${design}_TB
