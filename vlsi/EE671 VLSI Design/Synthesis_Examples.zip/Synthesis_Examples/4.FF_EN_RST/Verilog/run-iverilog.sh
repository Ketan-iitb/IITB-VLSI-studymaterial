#!/bin/sh

design="DFF"
rm -rf ${design}_TB
echo "Testing:" ${design}
iverilog -o ${design}_TB ${design}.v ${design}_TB.v
vvp ${design}_TB
