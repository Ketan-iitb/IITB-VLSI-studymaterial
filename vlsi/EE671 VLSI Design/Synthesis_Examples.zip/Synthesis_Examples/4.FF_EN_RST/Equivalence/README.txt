eqy -f Equivalence.eqy 
# This seems tobe going to na infinte loop

yosys Eq.tcl
# Works but provides false failure since primitves in primitives.v are being compared 
